#include "awtk.h"
#include "base/assets_manager.h"
#include "assets/inc/strings/en_US.data"
#include "assets/inc/strings/zh_CN.data"
#include "assets/inc/styles/default.data"
#include "assets/inc/styles/keyboard.data"
#include "assets/inc/ui/calibration_win.data"
#include "assets/inc/ui/kb_ascii.data"
#include "assets/inc/ui/kb_default.data"
#include "assets/inc/ui/kb_float.data"
#include "assets/inc/ui/kb_hex.data"
#include "assets/inc/ui/kb_int.data"
#include "assets/inc/ui/kb_phone.data"
#include "assets/inc/ui/kb_ufloat.data"
#include "assets/inc/ui/kb_uint.data"
#include "assets/inc/ui/keyboard.data"
#include "assets/inc/ui/main.data"
#include "assets/inc/ui/record.data"
#include "assets/inc/ui/setting.data"
#include "assets/inc/ui/system_bar.data"
#include "assets/inc/ui/timing.data"

ret_t assets_init(void) {
  assets_manager_t* rm = assets_manager();

  assets_manager_add(rm, strings_en_US);
  assets_manager_add(rm, strings_zh_CN);
  assets_manager_add(rm, style_default);
  assets_manager_add(rm, style_keyboard);
  assets_manager_add(rm, ui_calibration_win);
  assets_manager_add(rm, ui_kb_ascii);
  assets_manager_add(rm, ui_kb_default);
  assets_manager_add(rm, ui_kb_float);
  assets_manager_add(rm, ui_kb_hex);
  assets_manager_add(rm, ui_kb_int);
  assets_manager_add(rm, ui_kb_phone);
  assets_manager_add(rm, ui_kb_ufloat);
  assets_manager_add(rm, ui_kb_uint);
  assets_manager_add(rm, ui_keyboard);
  assets_manager_add(rm, ui_main);
  assets_manager_add(rm, ui_record);
  assets_manager_add(rm, ui_setting);
  assets_manager_add(rm, ui_system_bar);
  assets_manager_add(rm, ui_timing);

  tk_init_assets();
  return RET_OK;
}
