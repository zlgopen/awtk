import os
import sys 
AWTK_ROOT='D:\\2019\\awtk'
sys.path.append(os.path.join(AWTK_ROOT, "scripts"))
import update_res_common as common

APP_ROOT=os.getcwd()

ASSETS_ROOT=common.joinPath(APP_ROOT, 'assets')
ASSET_C=common.joinPath(APP_ROOT, 'assets.c')

common.init(AWTK_ROOT, ASSETS_ROOT, ASSET_C);

common.updateRes()
